const Auxwrap = (props) => props.children;

export default Auxwrap;
